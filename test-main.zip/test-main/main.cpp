#include <GL/freeglut.h>
#include <cmath>
#include <iostream>

float angleX = 0.0f;
float angleY = 0.0f;
float angleZ = 0.0f;

float rotationSpeed = 2.0f;

float cubeX = 0.0f;
float cubeY = 0.0f;
float cubeZ = -5.0f;

float moveSpeed = 0.02f;

float dirX = 0.01f;
float dirY = 0.005f;

bool rotateX = true;
bool rotateY = true;
bool rotateZ = true;

GLfloat colors[6][3] = {
    {1.0f, 0.0f, 0.0f},
    {0.0f, 1.0f, 0.0f},
    {0.0f, 0.0f, 1.0f},
    {1.0f, 1.0f, 0.0f},
    {1.0f, 0.0f, 1.0f},
    {0.0f, 1.0f, 1.0f}
};

void drawCube() {
    glBegin(GL_QUADS);

    glColor3fv(colors[0]);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);

    glColor3fv(colors[1]);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);

    glColor3fv(colors[2]);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);

    glColor3fv(colors[3]);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);

    glColor3fv(colors[4]);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);

    glColor3fv(colors[5]);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);

    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();

    glTranslatef(cubeX, cubeY, cubeZ);

    glRotatef(angleX, 1.0f, 0.0f, 0.0f);
    glRotatef(angleY, 0.0f, 1.0f, 0.0f);
    glRotatef(angleZ, 0.0f, 0.0f, 1.0f);

    drawCube();

    glPopMatrix();

    glutSwapBuffers();
}

void reshape(int width, int height) {
    float aspect = (height == 0) ? 1.0f : (float)width / (float)height;

    glViewport(0, 0, width, height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(45.0f, aspect, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case '1': rotateX = !rotateX; break;
    case '2': rotateY = !rotateY; break;
    case '3': rotateZ = !rotateZ; break;
    case '+': rotationSpeed += 0.5f; break;
    case '-': if (rotationSpeed > 0.5f) rotationSpeed -= 0.5f; break;
    case 'w': moveSpeed += 0.01f; break;
    case 's': if (moveSpeed > 0.01f) moveSpeed -= 0.01f; break;
    case 'r':
        angleX = angleY = angleZ = 0.0f;
        cubeX = cubeY = 0.0f;
        cubeZ = -5.0f;
        rotationSpeed = 2.0f;
        moveSpeed = 0.02f;
        dirX = 0.01f;
        dirY = 0.005f;
        break;
    case 27: exit(0); break;
    }
}

void specialKeys(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_UP:    cubeY += 0.1f; break;
    case GLUT_KEY_DOWN:  cubeY -= 0.1f; break;
    case GLUT_KEY_LEFT:  cubeX -= 0.1f; break;
    case GLUT_KEY_RIGHT: cubeX += 0.1f; break;
    case GLUT_KEY_PAGE_UP:   cubeZ += 0.5f; break;
    case GLUT_KEY_PAGE_DOWN: cubeZ -= 0.5f; break;
    }
}

void timer(int value) {
    if (rotateX) angleX += rotationSpeed;
    if (rotateY) angleY += rotationSpeed;
    if (rotateZ) angleZ += rotationSpeed;

    cubeX += dirX;
    cubeY += dirY;

    if (cubeX > 2.0f || cubeX < -2.0f) dirX = -dirX;
    if (cubeY > 1.5f || cubeY < -1.5f) dirY = -dirY;

    glutPostRedisplay();

    glutTimerFunc(16, timer, 0);
}

void init() {
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);

    glEnable(GL_DEPTH_TEST);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, 1.0f, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0.0f, 0.0f, -5.0f);
}

void showHelp() {
    std::cout << "1 - on/off x-axis rotation" << std::endl;
    std::cout << "2 - on/off y-axis rotation" << std::endl;
    std::cout << "3 - on/off x-axis rotation" << std::endl;
    std::cout << "+ - increase the rotation speed" << std::endl;
    std::cout << "- - reduce the rotation speed" << std::endl;
    std::cout << "w - increase the speed of movement" << std::endl;
    std::cout << "s - reduce the speed of movement" << std::endl;
    std::cout << "arrows - move the cube" << std::endl;
    std::cout << "Page Up/Down - approaching/distancing" << std::endl;
    std::cout << "r - resetting parameters" << std::endl;
    std::cout << "ESC - exit" << std::endl;
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    glutInitWindowSize(1280, 720);

    glutInitWindowPosition(300, 125);

    glutCreateWindow("Âðàùàþùèéñÿ è äâèæóùèéñÿ êóá");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);

    glutTimerFunc(16, timer, 0);

    showHelp();

    glutMainLoop();

    return 0;

}
